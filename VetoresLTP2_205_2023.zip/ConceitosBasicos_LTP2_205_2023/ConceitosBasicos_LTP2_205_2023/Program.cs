﻿Console.WriteLine("hello world");
string nome = "bernardo";
Console.WriteLine("olá você também tem pelo no cu?" + nome);
string nome ="mamador";
Console.WriteLine("vc é realmente um" + mamador);

